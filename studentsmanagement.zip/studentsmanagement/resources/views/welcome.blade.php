<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><center> 
<h1>Student Management System</h1><a href="create">Add Student</a>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $datas)
            <tr>
                <th>{{$datas['name']}}</th>
                <th>{{$datas['email']}}</th>
                <td><a href=delete/{{$datas->id}}>Delete</a></td>
                <td><a href=edit/{{$datas->id}}>Edit</a></td>
            
            </tr>
            @endforeach
        </tbody>

    </table></center>
</body>
</html>