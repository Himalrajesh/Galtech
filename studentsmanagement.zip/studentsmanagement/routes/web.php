<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', "App\Http\Controllers\Student@read");

Route::get('delete/{id}',"App\Http\Controllers\Student@delete");



Route::get('create',"App\Http\Controllers\Student@create");


Route::post('save-user',"App\Http\Controllers\Student@save");

Route::get('edit/{id}',"App\Http\Controllers\Student@edit");

Route::get('edit/update/{id}',"App\Http\Controllers\Student@update");

// Route::get('about',"App\Http\Controllers\Student@about");
