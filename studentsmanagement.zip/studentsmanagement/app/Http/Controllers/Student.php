<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class Student extends Controller
{
   
    public function read(){
        
        $data = Employee::all();
        
        return view('welcome',compact('data'));
    }
    public function delete($id){
        $data = Employee::find($id);
        $data->delete();
        return "deleted";

    }
    public function save(){
        $name = request('name');
        $email= request('email');
        $password = request('password');
// echo $password;
        Employee::create([
            'name'=>$name,
            'email'=>$email,
            'password'=>$password
        ]);
        return "inserted";


    }
    public function create()  {
        return view('create');
        
    }
    public function edit($id){
        $data = Employee::find($id);
        return view('edit',compact('data'));
    }
    public function update($id){
        $data = Employee::find($id);
        $data->update([
            "name"=>request('name'),
            "email"=>request('email')
           
        ]);
        return "updated";
    }
}
