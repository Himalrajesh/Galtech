<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><center> 
<h1>Student Management System</h1><a href="create">Add Student</a>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($datas['name']); ?></th>
                <th><?php echo e($datas['email']); ?></th>
                <td><a href=delete/<?php echo e($datas->id); ?>>Delete</a></td>
                <td><a href=edit/<?php echo e($datas->id); ?>>Edit</a></td>
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table></center>
</body>
</html><?php /**PATH C:\Users\himal\OneDrive\Desktop\Laravel\student\studentsmanagement\resources\views/welcome.blade.php ENDPATH**/ ?>