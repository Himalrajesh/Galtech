<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>
    <center>

        
<table style="width:100%">
  <tr>
    <th>NAME</th>
    <th>PLACE</th>
    <th>SALARY</th>
  </tr>
  
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($datas['name']); ?></td>
        <td> <?php echo e($datas['place']); ?></td>
        <td> <?php echo e($datas['salary']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
        </table>
    </center>
</body>
</html>
<?php /**PATH C:\Users\himal\OneDrive\Desktop\Laravel\student\studentsmanagement\resources\views/about.blade.php ENDPATH**/ ?>