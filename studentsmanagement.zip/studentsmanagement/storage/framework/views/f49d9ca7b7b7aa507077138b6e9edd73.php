<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="save-user" method="post">
        <?php echo csrf_field(); ?>
        Name  :<input type="text" name="name" id="">
        email  :<input type="email" name="email" id="">
        password : <input type="password" name="password" id="">
        <input type="submit" value="submit">

    </form>
</body>
</html><?php /**PATH C:\Users\himal\OneDrive\Desktop\Laravel\student\studentsmanagement\resources\views/create.blade.php ENDPATH**/ ?>