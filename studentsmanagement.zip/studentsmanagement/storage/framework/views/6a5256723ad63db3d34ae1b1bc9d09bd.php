<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="update/<?php echo e($data->id); ?>" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        Name  :<input type="text" name="name" id="" value=<?php echo e($data->name); ?>>
        email  :<input type="email" name="email" id="" value=<?php echo e($data->email); ?>>
        <input type="submit" value="submit">

    </form>
</body>
</html><?php /**PATH C:\Users\himal\OneDrive\Desktop\Laravel\student\studentsmanagement\resources\views/edit.blade.php ENDPATH**/ ?>